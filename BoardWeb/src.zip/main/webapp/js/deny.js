/**
 * 
 */

document.title = "접근 거부";

document.querySelector("#deny").innerHTML = `<h2>(⩌⩊⩌)</h2>`;